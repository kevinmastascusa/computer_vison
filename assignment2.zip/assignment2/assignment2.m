% List of images to process

imageFiles = {'hestain.png', 'gantrycrane.png'};

% Specify new dimensions for resizing
newWidthLarger = 500; % Example new width for larger image
newHeightLarger = 300; % Example new height for larger image
newWidthSmaller = 150; % Example new width for smaller image
newHeightSmaller = 100; % Example new height for smaller image

% Process each image
for i = 1:length(imageFiles)
    % Load an original image
    originalImage = imread(imageFiles{i});

    % Get the original dimensions of the current image
    [originalHeight, originalWidth, ~] = size(originalImage);

    % Check if the new dimensions are actually larger
    if newWidthLarger <= originalWidth || newHeightLarger <= originalHeight
        error('The specified larger dimensions are not larger than the original image.');
    end

    % Check if the new dimensions are actually smaller
    if newWidthSmaller >= originalWidth || newHeightSmaller >= originalHeight
        error('The specified smaller dimensions are not smaller than the original image.');
    end

    % Display and save the original image
    figure;
    imshow(originalImage);
    title(['Original Image: ' imageFiles{i}]);
    imwrite(originalImage, ['original_image_' num2str(i) '.png']);

    % Resize using nearest neighbor (larger and smaller) and save
    resizedImageNNLarger = nearestNeighborResize(originalImage, newWidthLarger, newHeightLarger);
    figure;
    imshow(resizedImageNNLarger);
    title('Larger Image - Nearest Neighbor');
    imwrite(resizedImageNNLarger, ['larger_nn_' num2str(i) '.png']);

    resizedImageNNSmaller = nearestNeighborResize(originalImage, newWidthSmaller, newHeightSmaller);
    figure;
    imshow(resizedImageNNSmaller);
    title('Smaller Image - Nearest Neighbor');
    imwrite(resizedImageNNSmaller, ['smaller_nn_' num2str(i) '.png']);

    % Resize using bilinear interpolation (larger and smaller) and save
    resizedImageBILarger = bilinearInterpolationResize(originalImage, newWidthLarger, newHeightLarger);
    figure;
    imshow(resizedImageBILarger);
    title('Larger Image - Bilinear Interpolation');
    imwrite(resizedImageBILarger, ['larger_bi_' num2str(i) '.png']);

    resizedImageBISmaller = bilinearInterpolationResize(originalImage, newWidthSmaller, newHeightSmaller);
    figure;
    imshow(resizedImageBISmaller);
    title('Smaller Image - Bilinear Interpolation');
    imwrite(resizedImageBISmaller, ['smaller_bi_' num2str(i) '.png']);
end
