function resizedImageBI = bilinearInterpolationResize(originalImage, newWidth, newHeight)
    [h, w, d] = size(originalImage);
    resizedImage = zeros(newHeight, newWidth, d, 'uint8');
    for x_prime = 1:newWidth
        for y_prime = 1:newHeight
            x = (x_prime - 0.5) * w / newWidth + 0.5;
            y = (y_prime - 0.5) * h / newHeight + 0.5;
            x1 = floor(x);
            x2 = ceil(x);
            y1 = floor(y);
            y2 = ceil(y);
            x1 = max(min(x1, w-1), 1);
            x2 = max(min(x2, w), 1);
            y1 = max(min(y1, h-1), 1);
            y2 = max(min(y2, h), 1);
            
            Q11 = double(originalImage(y1, x1, :));
            Q12 = double(originalImage(y2, x1, :));
            Q21 = double(originalImage(y1, x2, :));
            Q22 = double(originalImage(y2, x2, :));

            denom_x = max(x2 - x1, eps);
            denom_y = max(y2 - y1, eps);
            R1 = ((x2 - x) .* Q11 + (x - x1) .* Q21) / denom_x;
            R2 = ((x2 - x) .* Q12 + (x - x1) .* Q22) / denom_x;
            P = ((y2 - y) .* R1 + (y - y1) .* R2) / denom_y;
            
            resizedImage(y_prime, x_prime, :) = uint8(P);
        end
    end
    resizedImageBI = resizedImage;
end
