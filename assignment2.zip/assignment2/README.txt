README.txt

**Image Resizing with MATLAB**

**Project Overview:**
This MATLAB project allows you to resize images using both nearest neighbor and bilinear interpolation methods. You can choose to resize images to larger or smaller dimensions based on your preferences.

Files Included:
1. assignment2.m - The entry point script for this project.
2. nearestNeighborResize.m - Contains the nearest neighbor resizing function.
3. bilinearInterpolationResize.m - Contains the bilinear interpolation resizing function.
4. hestain.png: This image provides an example for resizing. Its original dimensions are w=303 and h=227 pixels.
5. gantrycrane.png: Another sample image for testing the resizing tool. Its original dimensions are w=400 and h=264 pixels.

Getting Started:

Prerequisites:
- You need to have MATLAB installed on your computer to run this project.

Step-by-Step Guide:

1. Organize Your Files:
   - Place the images you want to resize in the same directory as the project files (assignment2.m, nearestNeighborResize.m, bilinearInterpolationResize.m).
   - Ensure that the images have the correct file names and extensions (e.g., 'hestain.png' and 'gantrycrane.png').

2. Configure Your Resizing Preferences:
   - Open the assignment2.m script using MATLAB.
   - Inside the script, locate the following lines:

     % Specify new dimensions for resizing
     newWidthLarger = 500; % Example new width for larger image
     newHeightLarger = 300; % Example new height for larger image
     newWidthSmaller = 150; % Example new width for smaller image
     newHeightSmaller = 100; % Example new height for smaller image

   - Adjust the values of newWidthLarger, newHeightLarger, newWidthSmaller, and newHeightSmaller to set your desired dimensions for resizing.
   -Size Validation: Before proceeding with resizing, the tool performs size validation checks. It confirms that the new dimensions specified for resizing are appropriate for the chosen operation:
   -Enlarging Images: If you intend to make your images larger, the tool ensures that the new dimensions are genuinely larger than the original dimensions. This prevents accidental size reduction when enlarging images.
   -Reducing Dimensions: When reducing image dimensions, the tool checks that the new dimensions are genuinely smaller than the original dimensions. This prevents unintentional image enlargement.

3. Run the Script:
   - Run the script in MATLAB by clicking the "Run" button or typing assignment2 in the MATLAB command window.
   - The script will process the images according to your specified dimensions and resizing methods.

4. View and Use Resized Images:
   - The resized images will be displayed and saved in the same directory.
   - You will find the following images for each input image:
     - Original Image
     - Larger Image using Nearest Neighbor
     - Larger Image using Bilinear Interpolation
     - Smaller Image using Nearest Neighbor
     - Smaller Image using Bilinear Interpolation

Important Note:

Before running the assignment2.m script, please ensure the following:

    File Locations: Make sure that all required files, including the images you want to process, are located in the same directory as the script. This ensures that the script can access the necessary resources without issues.

    Current Folder: It's essential to set the current folder of MATLAB to the directory containing assignment2.m and the image files. This step ensures that MATLAB can locate and execute the script correctly.

    Image Locations: Double-check that the image files (e.g., 'hestain.png' and 'gantrycrane.png') are in the correct location. The script expects these images to be in the same directory as assignment2.m.
	
Output Images Directory

In the same directory as assignment2.m, you will find a directory named "Output Images." This directory contains the processed images that you will obtain by running assignment2. The processed images include both the larger and smaller versions of the input images 'hestain.png' and 'gantrycrane.png'.

After running the assignment2.m script, you can access the processed images in the "Output Images" directory. These images are named according to the processing method (e.g., nearest neighbor or bilinear interpolation) and the original image's name. Feel free to explore and use these images as needed.