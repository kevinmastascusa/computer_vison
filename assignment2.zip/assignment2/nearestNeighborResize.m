function resizedImageNN = nearestNeighborResize(originalImage, newWidth, newHeight)
    [h, w, d] = size(originalImage);
    resizedImage = zeros(newHeight, newWidth, d, 'uint8');
    for x_prime = 1:newWidth
        for y_prime = 1:newHeight
            x = round(x_prime * w / newWidth);
            y = round(y_prime * h / newHeight);
            x = max(min(x, w), 1);
            y = max(min(y, h), 1);
            resizedImage(y_prime, x_prime, :) = originalImage(y, x, :);
        end
    end
    resizedImageNN = resizedImage;  % Assign the result to the output variable
end





