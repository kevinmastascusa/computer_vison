% Load your input image
image = imread('peppers.png');

% Convert to grayscale if it's a color image
if size(image, 3) == 3
    grayscale_image = rgb2gray(image);
else
    grayscale_image = image;
end

% Define the kernel size (K) and Gaussian variance (sigma)
kernelSize = 9; % Adjust the kernel size as needed
sigma = 3; % Adjust the sigma value as needed

% Call the custom function to perform Gaussian smoothing with zero padding
smoothedImage = customGaussianSmoothingWithZeroPadding(grayscale_image, kernelSize, sigma);

% Display or save the smoothed image as needed
imshow(smoothedImage); % Display the smoothed image
imwrite(smoothedImage, 'smoothed_image.png'); % Save the smoothed image

% Load your smoothed image from Part 2
smoothedImage = imread('smoothed_image.png'); % Adjust the filename as needed

% Convert the smoothed image to grayscale if necessary
if size(smoothedImage, 3) == 3
    grayscale_smoothed_image = rgb2gray(smoothedImage);
else
    grayscale_smoothed_image = smoothedImage;
end

% Initialize arrays to store gradient images
gradient_x = zeros(size(grayscale_smoothed_image));
gradient_y = zeros(size(grayscale_smoothed_image));

% Compute gradients using finite differences
for i = 2:size(grayscale_smoothed_image, 1) - 1
    for j = 2:size(grayscale_smoothed_image, 2) - 1
        % Compute gradient in the x direction
        gradient_x(i, j) = grayscale_smoothed_image(i, j + 1) - grayscale_smoothed_image(i, j - 1);
        
        % Compute gradient in the y direction
        gradient_y(i, j) = grayscale_smoothed_image(i + 1, j) - grayscale_smoothed_image(i - 1, j);
    end
end

% Compute the magnitude of gradients
gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);
 % Compute gradient magnitude
    gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);
    
    % Save the gradient magnitude image
% Display or save the gradient images as needed

% Save Gradient in X as a separate figure
figure;
imshow(abs(gradient_x), []);
title('Gradient in X');
saveas(gcf, 'gradient_x.png');

% Save Gradient in Y as a separate figure
figure;
imshow(abs(gradient_y), []);
title('Gradient in Y');
saveas(gcf, 'gradient_y.png');

% Save Gradient Magnitude as a separate figure
figure;
imshow(gradient_magnitude, []);
title('Gradient Magnitude');
saveas(gcf, 'gradient_magnitude.png');


% Load your input image
image = imread('circles.gif');

% Convert the input image to grayscale if it's not already
if size(image, 3) == 3
    grayscale_image = rgb2gray(image);
else
    grayscale_image = image;
end

% Define different combinations of kernel sizes (N) and sigmas (sigma)
combinations = [
    5, 1;
    9, 2;
    15, 3;
    21, 4
];

% Create a subplot to display the results
figure;
subplot(2, 3, 1), imshow(grayscale_image), title('Original Image');

% Apply Gaussian smoothing with different combinations and display results
for i = 1:size(combinations, 1)
    kernelSize = combinations(i, 1);
    sigma = combinations(i, 2);
    
    % Apply Gaussian smoothing
    smoothed_image = customGaussianSmoothingWithZeroPadding(grayscale_image, kernelSize, sigma);
    
    % Display the smoothed image
    subplot(2, 3, i + 1), imshow(smoothed_image), title(['N=', num2str(kernelSize), ', \sigma=', num2str(sigma)]);
    
    % Save the smoothed images with different parameters
    imwrite(smoothed_image, ['smoothed_image_', num2str(i), '.png']);
    
end

% Save the entire figure with subplots
saveas(gcf, 'parameter_combinations.png');

% Apply Gaussian smoothing with different combinations and display results
for i = 1:size(combinations, 1)
    kernelSize = combinations(i, 1);
    sigma = combinations(i, 2);
    
    % Apply Gaussian smoothing
    smoothed_image = customGaussianSmoothingWithZeroPadding(grayscale_image, kernelSize, sigma);
    
    % Compute gradients using finite differences
    gradient_x = zeros(size(smoothed_image));
    gradient_y = zeros(size(smoothed_image));

    for row = 2:size(smoothed_image, 1) - 1
        for col = 2:size(smoothed_image, 2) - 1
            gradient_x(row, col) = smoothed_image(row, col + 1) - smoothed_image(row, col - 1);
            gradient_y(row, col) = smoothed_image(row + 1, col) - smoothed_image(row - 1, col);
        end
    end

    % Compute gradient magnitude
    gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);
    
    % Display the gradient magnitude image
    figure;
    imshow(gradient_magnitude, []);
    title(['Gradient Magnitude - N=', num2str(kernelSize), ', \sigma=', num2str(sigma)]);
    
    % Save the current image
    saveas(gcf, ['gradient_magnitude_image_', num2str(kernelSize), '_', num2str(sigma), '.png']);
    
    % Close the current figure
    close;
end
% Load the gradient magnitude image 
gradient_magnitude = imread('gradient_magnitude.png'); % Adjust the filename as needed

% Define low and high thresholds
low_threshold = 40;  % Adjust as needed
high_threshold = 80; % Adjust as needed

% Initialize the edge map as a binary image
edge_map = zeros(size(gradient_magnitude));

% Apply hysteresis thresholding
for i = 1:size(gradient_magnitude, 1)
    for j = 1:size(gradient_magnitude, 2)
        % Check if the gradient magnitude is above the high threshold
        if gradient_magnitude(i, j) > high_threshold
            edge_map(i, j) = 1;
        % Check if the gradient magnitude is above the low threshold and borders a high gradient pixel
        elseif gradient_magnitude(i, j) > low_threshold
            % Check the 8 neighboring pixels for high gradient values
            neighbors = gradient_magnitude(max(1, i-1):min(size(gradient_magnitude, 1), i+1), ...
                                            max(1, j-1):min(size(gradient_magnitude, 2), j+1));
            if any(neighbors(:) > high_threshold)
                edge_map(i, j) = 1;
            end
        end
    end
end

% Display or save the edge map as needed

% Assuming 'edge_map' is your binary edge map
gray_edge_map = im2gray(edge_map); % Convert to grayscale

% Save the grayscale edge map
imwrite(gray_edge_map, 'gray_edge_map.png'); % Save as grayscale


% Load your smoothed image from Part 2
smoothedImage = imread('smoothed_image.png'); % Adjust the filename as needed

% Convert the smoothed image to grayscale if necessary
if size(smoothedImage, 3) == 3
    grayscale_smoothed_image = rgb2gray(smoothedImage);
else
    grayscale_smoothed_image = smoothedImage;
end

% Initialize arrays to store gradient images
gradient_x = zeros(size(grayscale_smoothed_image));
gradient_y = zeros(size(grayscale_smoothed_image));

% Compute gradients using finite differences
for i = 2:size(grayscale_smoothed_image, 1) - 1
    for j = 2:size(grayscale_smoothed_image, 2) - 1
        % Compute gradient in the x direction
        gradient_x(i, j) = grayscale_smoothed_image(i, j + 1) - grayscale_smoothed_image(i, j - 1);
        
        % Compute gradient in the y direction
        gradient_y(i, j) = grayscale_smoothed_image(i + 1, j) - grayscale_smoothed_image(i - 1, j);
    end
end

% Calculate the gradient magnitude directly
gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);

% Create an image to store the non-maximum suppressed results
non_maximum_suppressed = zeros(size(gradient_magnitude));

% Define angle thresholds for different directions (in radians)
angle_thresholds = [
    -pi/8, pi/8;     % Left and right
    -5*pi/8, -3*pi/8; % Up and down
    -3*pi/8, -pi/8;  % Up-right and down-left
    -7*pi/8, -5*pi/8; % Up-left and down-right
];

% Loop through each pixel in the gradient magnitude image
for i = 2:size(gradient_magnitude, 1) - 1
    for j = 2:size(gradient_magnitude, 2) - 1
        % Check if i and j are within bounds
        if i >= 2 && i <= size(gradient_magnitude, 1) - 1 && ...
           j >= 2 && j <= size(gradient_magnitude, 2) - 1
            % Get the gradient angle of the current pixel
            angle = atan2(gradient_y(i, j), gradient_x(i, j));
        
            % Check if the gradient magnitude of the current pixel is the largest among its neighbors
            if (angle >= angle_thresholds(1, 1) && angle < angle_thresholds(1, 2)) || ...
               (angle >= angle_thresholds(2, 1) && angle < angle_thresholds(2, 2)) || ...
               (angle >= angle_thresholds(3, 1) && angle < angle_thresholds(3, 2)) || ...
               (angle >= angle_thresholds(4, 1) || angle < angle_thresholds(4, 2))
                % Compare with neighbors in the specified directions
                neighbors = [
                    gradient_magnitude(i, j+1);   % Right
                    gradient_magnitude(i+1, j);   % Down
                    gradient_magnitude(i+1, j+1); % Down-right
                    gradient_magnitude(i+1, j-1); % Down-left
                ];
            
                % If the current magnitude is the largest, keep it; otherwise, set to 0
                if all(gradient_magnitude(i, j) >= neighbors)
                    non_maximum_suppressed(i, j) = gradient_magnitude(i, j);
                end
            end
        end
    end
end

% Display or save the non-maximum suppressed image as needed
imshow(non_maximum_suppressed, []); % Display the non-maximum suppressed image
imwrite(uint8(non_maximum_suppressed), 'non_maximum_suppressed.png'); % Save the result as grayscale
