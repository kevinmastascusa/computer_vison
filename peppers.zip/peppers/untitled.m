% Define the kernels
kernel_x = [-1/3, 0, 1/3; -1/3, 0, 1/3; -1/3, 0, 1/3];
kernel_y = [-1/3, -1/3, -1/3; 0, 0, 0; 1/3, 1/3, 1/3];

% Define the image I
I = [7, 7, 6; 3, 7, 2; 5, 4, 7];

% Convolve the image with the x and y kernels
G_x = conv2(I, kernel_x, 'same');
G_y = conv2(I, kernel_y, 'same');

% Calculate the gradient magnitude and direction at the center pixel
center_pixel = [2, 2]; % Center pixel coordinates (0-based indexing)
magnitude = sqrt(G_x(center_pixel(1), center_pixel(2))^2 + G_y(center_pixel(1), center_pixel(2))^2);
direction = atan2(G_y(center_pixel(1), center_pixel(2)), G_x(center_pixel(1), center_pixel(2)));

% Display the results
fprintf('Gradient Magnitude at Center Pixel: %.2f\n', magnitude);
fprintf('Gradient Direction at Center Pixel: %.2f radians\n', direction);
