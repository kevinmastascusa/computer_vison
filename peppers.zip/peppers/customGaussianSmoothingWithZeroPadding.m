function smoothedImage = customGaussianSmoothingWithZeroPadding(image, kernelSize, sigma)
    % Create the Gaussian kernel
    [X, Y] = meshgrid(-floor(kernelSize/2):floor(kernelSize/2), -floor(kernelSize/2):floor(kernelSize/2));
    gaussianKernel = exp(-(X.^2 + Y.^2) / (2 * sigma^2));
    gaussianKernel = gaussianKernel / sum(gaussianKernel(:));  % Normalize the kernel

    % Initialize the padded image with zeros
    [rows, cols, numChannels] = size(image);
    padSize = floor(kernelSize / 2);
    paddedRows = rows + 2 * padSize;
    paddedCols = cols + 2 * padSize;
    paddedImage = zeros(paddedRows, paddedCols, numChannels, 'like', image);

    % Copy the original image into the center of the padded image
    paddedImage(padSize + 1:end - padSize, padSize + 1:end - padSize, :) = image;

    % Initialize the smoothed image
    smoothedImage = zeros(rows, cols, 'like', image);

    % Apply Gaussian blur (convolution) with manual zero padding
    for i = 1:rows
        for j = 1:cols
            for k = 1:numChannels  % For each color channel
                % Extract the region of interest from the padded image
                region = double(paddedImage(i:i+2*padSize, j:j+2*padSize, k));

                % Apply the kernel to the region
                smoothedImage(i, j, k) = sum(sum(region .* gaussianKernel));
            end
        end
    end
end
